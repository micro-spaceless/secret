<?php

return [
    'bot_token' => '1830036992:AAHe4NuURtpqvovSgOcFJAUpOz3Bi__DRS8',
    'chat_id'   => '1008359300',
];
